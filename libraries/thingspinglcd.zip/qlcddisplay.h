#ifndef __QLCDDISPLAY_H__
#define __QLCDDISPLAY_H__
#include "Arduino.h"
#include "Wire.h"
#include "LiquidCrystal_I2C.h"

enum DisplaySize {SIXTEENTWO, SIXTEENFOUR};

class QLcdDisplay {
  public:
    QLcdDisplay(uint8_t pin1, uint8_t pin2, byte addr) ;
    QLcdDisplay(uint8_t pin1, uint8_t pin2) ;
    //QLcdDisplay(DisplaySize dsize, uint8_t pin1, uint8_t pin2) ;
    byte getAddress() {return addr ; } 
    void displayText(String) ;
    void displayText(String, String) ;
    void backlight_off();
    void backlight_on() ; 

  private :
    LiquidCrystal_I2C * lcd;
    uint8_t cols ;
    uint8_t rows ;
    uint8_t _buzzerpin ;
    int buzzerState ;
    uint8_t l1spaces ;
    uint8_t l2spaces ;
    String l1 ;
    String l2 ;
    byte addr ; 
    uint sdapin; 
    uint sclpin; 
    

    void init(DisplaySize, uint8_t, uint8_t) ;
    bool isI2CFound(byte address); 
};


#endif
