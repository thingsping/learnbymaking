#include "qlcddisplay.h"


bool QLcdDisplay ::  isI2CFound(byte address) {
   Wire.beginTransmission(address);
   byte error = Wire.endTransmission();    
  if (error == 0)
    return true ; 
  else {
    // /Serial.println("Error for " + String(address) + " = " + String(error));
    return false ; 
  }
}

QLcdDisplay :: QLcdDisplay(uint8_t pin1, uint8_t pin2) {
    this -> addr = 0 ;  
    init(SIXTEENTWO, pin1, pin2); 
    
}

QLcdDisplay :: QLcdDisplay(uint8_t pin1, uint8_t pin2, byte address) {
  this -> addr = address ; 
  init(SIXTEENTWO, pin1, pin2) ;
}

/*
QLcdDisplay :: QLcdDisplay( DisplaySize dsize, uint8_t pin1, uint8_t pin2) {
  init(dsize, pin1, pin2, 0x27) ;
}
*/


void QLcdDisplay :: init(DisplaySize dsize, uint8_t pin1, uint8_t pin2) {
  //Serial.begin(9600); 
  if (dsize == SIXTEENTWO) {
    cols = 16 ;
    rows = 2 ;
  }
  else {
    // WONT WORK RIGHT NOW - AS WE DON'T HAVE FOUR LINE HELPER
    cols = 16 ;
    rows = 4  ;
  }
  l1spaces = 0 ;
  l2spaces = 0 ;
  sdapin = pin1 ; 
  sclpin = pin2 ; 
  Wire.begin(sdapin, sclpin); //this is of the foramt Wire.begin(int sda,int scl);
  if (addr == 0 ){
    if (isI2CFound(0x27)) {
      addr = 0x27; 
    } else if (isI2CFound(0x3F)){
      addr = 0x3F ;
    } else {
       for(int a  = 1; a < 127; a++ )
       {
         if (isI2CFound(a)) {
           addr = a; 
           break ; 
         }
       }
    }
  }

  lcd = new LiquidCrystal_I2C (addr, cols, rows);
  lcd -> begin();
  //lcd -> noBacklight();
  //lcd -> autoscroll();
  lcd -> noBlink() ; 
  lcd -> noCursor();   
}

void QLcdDisplay :: displayText(String text) {
  String line1 = text;
  String line2 = "" ;
  int index = line1.indexOf("\n");
  if (index != -1) {
    line2 = line1.substring(index + 1);
    line1 = line1.substring(0, index);
  } 
  displayText(line1, line2);
}

void QLcdDisplay :: displayText(String line1, String line2) {
  if (lcd != 0) {
    lcd -> clear() ;
    line1.trim() ;
    line2.trim() ;
    if (!line1.equals("")){
      l1 = "" ; 
      if(line1.length() < cols) {
        l1spaces = cols - line1.length() ;
        l1spaces = l1spaces / 2 ;
        for (int i =0 ; i < l1spaces ; i++){
          l1.concat(" ");
        }
      }
      else if (line1.length() > cols) {
        l1spaces = cols +1 ; // means no spaces required
      }
      l1.concat(line1);
    }

    if (!line2.equals("")) {
      l2 = "" ; 
      if(line2.length() < cols) {
        l2spaces = cols - line2.length() ;
        l2spaces = l2spaces / 2 ;
        for (int i =0 ; i < l2spaces ; i++){
          l2.concat(" ");
        }
      }
      else if (line2.length() > cols) {
        l2spaces = cols + 1  ;
      }
      l2.concat(line2);
    }
    lcd -> setCursor(0,0);
    lcd -> print(l1);
    lcd -> setCursor(0,1);
    lcd -> print(l2);
  }
}

void  QLcdDisplay :: backlight_off(){
  if (lcd != 0)
    lcd -> noBacklight();
}

void  QLcdDisplay :: backlight_on() {
  if (lcd != 0)
    lcd -> backlight() ; 
}

