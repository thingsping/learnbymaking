This library has been shortened and modified by Qantom Software Private Limited and is not 
an original work. The orginal work was done by the authors at : 

https://github.com/googlesamples/firebase-arduino/archive/master.zip

The above code was released under Apache 2.0 license, a permissive opensource library. A copy of the Apache License is included with this library's files.

The firebase-arduino library uses the Arduino-Json library. The Arduino-Json library is written and maintained by 
Benoît Blanchon and is available at https://github.com/bblanchon/ArduinoJson. 

We have included the Arduino-JSON library as a part of the firebase library itself to ensure compatibility with the 
version we are using for the ThingsPing kits. 

The Arduino-JSON has been released under MIT license, another permissive license. 

## Disclaimer
*This is not an official Google product*.
